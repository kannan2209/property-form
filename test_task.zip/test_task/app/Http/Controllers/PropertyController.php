<?php
/*
	Controller name: property
	Created date: 18-12-2016
	Updated date: 18-12-2016
*/
namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Requests\PublishPropertyRequest;
use App\Property;
use DB;

class PropertyController extends Controller
{
	public function index()
	{
		$data['property'] = Property::get();
		return view('property', $data);
	}
   
	public function show()
	{
   
	}
   
	public function get_property_data()
    {
		/* Fetch a post data */
		$request = $_POST;
		$name = $request['name'];
		$start_price = $request['start_price'];
		$end_price = $request['end_price'];
		$bedrooms = $request['bedrooms'];
		$bathrooms = $request['bathrooms'];
		$storeys = $request['storeys'];
		$garages = $request['garages'];
		
		/* Search query for posted values */
		$property =  DB::table('property');
		if($name != '') {
			$property->where('name', 'like', '%' . $name . '%');
		}
		if($start_price != '' && $end_price != '') {
			$property->whereBetween('price', [$start_price, $end_price]);
		}
		if($bedrooms != '') {
			$property->where('bedrooms', $bedrooms);
		}
		if($bathrooms != '') {
			$property->where('bathrooms', $bathrooms);
		}
		if($storeys != '') {
			$property->where('storeys', $storeys);
		}
		if($garages != '') {
			$property->where('garages', $garages);
		}
		$properties = $property->get();
		
		/* Data pass to "designData" function for table design */
		$result = $this->designData($properties);
		echo json_encode($result);
		exit;
	}
	
	public function designData($property)
	{
		$res = '';
		if(empty($property)) {
			$res .= '<tr><td style="text-align:center;" colspan="6">No property found</td>';
		}
		
		foreach($property as $pro) {
			$res .= '<tr><td>'.$pro->name.'</td>';
			$res .= '<td>'.$pro->price.'</td>';
			$res .= '<td>'.$pro->bedrooms.'</td>';
			$res .= '<td>'.$pro->bathrooms.'</td>';
			$res .= '<td>'.$pro->storeys.'</td>';
			$res .= '<td>'.$pro->garages.'</td>';
		}
		return $res;
	}
}
