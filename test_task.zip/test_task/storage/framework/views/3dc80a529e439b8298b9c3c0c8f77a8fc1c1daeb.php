<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en" class="no-js">
<!--<![endif]-->
<head>
	<meta charset="utf-8"/>
	<title>Property | <?php echo $__env->yieldContent('pageTitle'); ?></title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1" name="viewport"/>
	<meta content="" name="description"/>
	<meta content="" name="author"/>
	
	<script type="text/javascript">
		var APP_URL = <?php echo json_encode(url('/')); ?>;
	</script>

</head>
<body>
	<?php echo $__env->yieldContent('body'); ?>
	
	<script src="<?php echo e(asset("public/assets/scripts/jquery-latest.min.js")); ?>" type="text/javascript"></script>	
	<script src="<?php echo e(asset("public/assets/scripts/bootstrap.min.js")); ?>" type="text/javascript"></script>	
	<script src="<?php echo e(asset("public/assets/scripts/datatables.min.js")); ?>" type="text/javascript"></script>	
	

	<?php echo $__env->yieldContent('scripts'); ?>
	
</body>
</html>