	<div class="col-sm-12">
		<?php echo "sdfsdf"; ?>
	</div>

			





<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>